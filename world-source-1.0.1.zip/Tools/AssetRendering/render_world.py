# SPDX-License-Identifier: GPL-3.0-only
# KOMA Studio contributions to this rendering script, 2026.
# Supplied without warranty; see the included 22i-LICENSE.txt for GPLv3 terms.
import bpy, sys, os, math
from mathutils import Vector
root=os.path.abspath(os.path.join(os.path.dirname(__file__),'../..'))
name=sys.argv[sys.argv.index('--')+1]
src=os.path.join(root,'ArtSource/World')
out=os.path.join(root,'Assets/MemeClicker/Resources/World')
ids={'creeper':0,'zombie':1,'skeleton':2,'noob':3,'ct':4,'enderman':5,'slime':6,'spider':7,'magmacube':8,'terrorist':9}
if name in ('creeper','zombie','skeleton','enderman','slime','spider','magmacube'):
    bpy.ops.wm.open_mainfile(filepath=os.path.join(src,name+'.blend'))
    for obj in list(bpy.data.objects):
        if obj.type!='MESH': continue
        remove=(name=='creeper' and obj.name.endswith('2')) or (name=='zombie' and obj.name.startswith('top.head')) or (name=='skeleton' and (not obj.name.startswith('skely_') or obj.name[-2:].isdigit()))
        if name=='enderman': remove=not obj.name.startswith('end_') or obj.name[-2:].isdigit()
        if name=='slime' and obj.name=='Slime_outside': remove=True
        if remove: bpy.data.objects.remove(obj,do_unlink=True)
    mat=bpy.data.materials.new('Downloaded Pixel Perfection'); mat.use_nodes=True
    nodes=mat.node_tree.nodes; bs=nodes.get('Principled BSDF')
    tex=nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(os.path.join(src,'textures',name+'.png'));tex.interpolation='Closest'
    mat.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
    bs.inputs['Roughness'].default_value=1
    for obj in bpy.data.objects:
        if obj.type=='MESH':
            obj.data.materials.clear();obj.data.materials.append(mat)
    bpy.context.scene.frame_set(1)
    if name in ('zombie','enderman','spider'):
        for obj in bpy.data.objects:
            if obj.type=='ARMATURE': obj.data.pose_position='REST'
else:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=os.path.join(src,name+'.glb'))
    if name=='terrorist':
        for obj in list(bpy.data.objects):
            if obj.type=='MESH' and obj.name=='Icosphere': bpy.data.objects.remove(obj,do_unlink=True)
    if name=='ct':
        for obj in list(bpy.data.objects):
            if obj.type=='MESH' and obj.name!='Object_3': bpy.data.objects.remove(obj,do_unlink=True)
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.samples=16
scene.render.resolution_x=384;scene.render.resolution_y=512;scene.render.resolution_percentage=100
scene.render.film_transparent=True;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA'
scene.view_settings.view_transform='Standard'
world=bpy.data.worlds.new('Studio');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.65,.7,.8,1);world.node_tree.nodes['Background'].inputs[1].default_value=.7;scene.world=world
meshes=[o for o in scene.objects if o.type=='MESH' and not o.hide_render]
corners=[o.matrix_world@Vector(c) for o in meshes for c in o.bound_box]
lo=Vector(tuple(min(c[i] for c in corners) for i in range(3)));hi=Vector(tuple(max(c[i] for c in corners) for i in range(3)))
center=(lo+hi)/2; height=max(hi.z-lo.z,.1)
print('BOUNDS',name,tuple(lo),tuple(hi),flush=True)
camdata=bpy.data.cameras.new('Sprite camera');cam=bpy.data.objects.new('Sprite camera',camdata);scene.collection.objects.link(cam);scene.camera=cam
camdata.type='ORTHO';camdata.ortho_scale=max(height*1.2,(hi.x-lo.x)*1.6)
cam.location=center+Vector((height*.28,-height*2.5,height*.15));cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler()
if name=='noob':
    cam.location=center+Vector((-height*2.5,-height*.28,height*.15));cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler()
lightdata=bpy.data.lights.new('Key','AREA');lightdata.energy=height*height*85;lightdata.shape='DISK';lightdata.size=height*2
light=bpy.data.objects.new('Key',lightdata);scene.collection.objects.link(light);light.location=center+Vector((-height,-height,height*2));light.rotation_euler=(center-light.location).to_track_quat('-Z','Y').to_euler()
if name=='crossroads':
    scene.render.resolution_x=1440;scene.render.resolution_y=810;scene.render.film_transparent=False
    camdata.ortho_scale=max(hi.x-lo.x,hi.y-lo.y)*.8
    cam.location=center+Vector((height*1.5,-height*2.5,height*1.7));cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=os.path.join(out,'map3.png');bpy.ops.render.render(write_still=True)
else:
    scene.render.filepath=os.path.join(out,'mob'+str(ids[name])+'.png');bpy.ops.render.render(write_still=True)
