# Лицензия собственного вклада в ограниченную адаптацию

KOMA Studio, 2026: собственный вклад в Assets/MemeClicker/Resources/World/
mob0.png, mob1.png, mob2.png, mob5.png, mob6.png, mob7.png, mob8.png и
Tools/AssetRendering/render_world.py предоставляется под GNU GPL version 3.
Полный текст: ArtSource/World/22i-LICENSE.txt. Эти материалы поставляются
без гарантии, как предусмотрено разделами 15–16 GPLv3.

Исходные модели 22i сохраняют GPLv3 и собственные уведомления.
Текстуры XSSheep / Pixel Perfection, MysticTempest и kingoscargames сохраняют
CC BY-SA 4.0, авторство и сведения о прежних изменениях. Вклад в адаптацию
CC BY-SA 4.0 разрешено предоставлять под GPLv3 согласно официальному списку:
https://creativecommons.org/compatible-licenses/
https://creativecommons.org/licenses/by-sa/4.0/legalcode.en

Этот документ не лицензирует всю Unity-игру или чужие коммерческие пакеты.
Права на изображённые сторонние объекты и товарные знаки не приобретаются
посредством изменения лицензионного уведомления.
